﻿using System.ComponentModel.DataAnnotations;

namespace Collaborative_Resource_Management_System.Models
{
    public class Role
    {
        public int RoleID { get; set; }

        public string RoleName { get; set; }
    }
}
